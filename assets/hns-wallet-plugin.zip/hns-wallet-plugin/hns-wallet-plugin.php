<?php
/*
Plugin Name: HNS Wallet Plugin
Description: A simple WordPress plugin to respond to .well-known/wallets/HNS route with a customizable wallet.
Version: 1.0
Author: Nathan Woodburn
*/


function hns_wallet_rewrite_rule() {
    add_rewrite_rule('^\.well-known/wallets/HNS/?$', 'index.php?hns_wallet=true', 'top');
}
add_action('init', 'hns_wallet_rewrite_rule');

function hns_wallet_query_vars($vars) {
    $vars[] = 'hns_wallet';
    return $vars;
}
add_filter('query_vars', 'hns_wallet_query_vars');

function hns_wallet_admin_menu() {
    add_menu_page(
        'HNS Wallet Settings',
        'HNS Wallet',
        'manage_options',
        'hns-wallet-settings',
        'hns_wallet_settings_page'
    );
}
add_action('admin_menu', 'hns_wallet_admin_menu');

function hns_wallet_settings_page() {
    if (isset($_POST['hns_wallet_response'])) {
        update_option('hns_wallet_response', sanitize_text_field($_POST['hns_wallet_response']));
    }
    
    $current_response = get_option('hns_wallet_response', 'hs1qd8ckjvjwypn99wtw4yssjjfpj96h9epuxuf6km');

    echo '<div class="wrap">';
    echo '<h2>HNS Wallet Settings</h2>';
    echo '<form method="post" action="">';
    echo '<label for="hns_wallet_response">Custom Response:</label><br />';
    echo '<input type="text" name="hns_wallet_response" value="' . esc_attr($current_response) . '" /><br /><br />';
    echo '<input type="submit" class="button button-primary" value="Save" />';
    echo '</form>';
    echo '<br />';
    echo '<p>After saving, you should clear the redirect cache by going to Permalinks and saving as anything but plain</p>';
    echo '</div>';
}

function hns_wallet_route_handler() {
    if (get_query_var('hns_wallet')) {
        $custom_response = get_option('hns_wallet_response', 'hs1qd8ckjvjwypn99wtw4yssjjfpj96h9epuxuf6km');
        echo esc_html($custom_response);
        exit;
    }
}
add_action('template_redirect', 'hns_wallet_route_handler');

function hns_stop_trailing_slash_redirect($redirect_url, $requested_url) {
    $trailing_slash = trailingslashit(site_url());
    if ($requested_url == $trailing_slash . 'HNS') {
        return $requested_url;
    }
    return $redirect_url;
}
add_filter('redirect_canonical', 'hns_stop_trailing_slash_redirect', 10, 2);
